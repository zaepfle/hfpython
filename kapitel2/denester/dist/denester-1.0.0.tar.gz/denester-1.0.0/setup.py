from distutils.core import setup

setup(
    name = 'denester',
    version = '1.0.0',
    py_modules = ['denester'],
    author = 'hzaepfle',
    author_email = 'horst.zaepfle@gmail.com',
    url = 'https://github.com/zaepfle/hfpython',
    description = 'simple printing of nested lists',
    )
